print("This is TECHIN 516 - Robotics Lab 1")

print("example1.py file")