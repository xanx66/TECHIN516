print("This is TECHIN 516 - Robotics Lab 1")

print("example2.py file")